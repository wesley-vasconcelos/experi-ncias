var $target = $('.cursos'),
animationclass = '.cursos-start';
 offset = $(window).height() * 3/4;


function cursosScroll() {
    var documentTop = $(document).scrolltop();

    $target.each(function(){
        var itemtop = $(this).offset().top;
        if(documentTop > itemtop - offset) {
            $(this).addclass(animationclass);   
        } else {
            $(this).removeclass(animationclass);
        }
    })
}

cursosScroll(); 

$(document).scroll(function(){
    cursosScroll();
} )
console.log()